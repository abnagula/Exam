package com.capgemini.re.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

import com.capgemini.re.exception.TruckException;


public class DBConnection {
	
	private static Connection connection = null;
	private static DBConnection instance = null;
	private static Properties properties = null;
	private static OracleDataSource dataSource = null;
	
	private DBConnection() throws TruckException {
		try {
			properties = loadProperties();
			dataSource = prepareDataSource();
		} catch (IOException e) {
			throw new TruckException(
					" Could not read the database details from properties file ");
		} catch (SQLException e) {
			throw new TruckException(e.getMessage());
		}

	}
	
	/**
	 * returns properties objects
	 * @return
	 * @throws IOException
	 */

	private Properties loadProperties() throws IOException {

		if (properties == null) {
			Properties newProps = new Properties();
			String fileName = "resources/Database.Properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return properties;
		}
	}
	
	
	private OracleDataSource prepareDataSource() throws SQLException {

		if (dataSource == null) {
			if (properties != null) {
				String connectionURL = properties.getProperty("url");
				String username = properties.getProperty("username");
				String password = properties.getProperty("password");

				dataSource = new OracleDataSource();
				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}
	
	public static DBConnection getInstance() throws TruckException{
		synchronized (DBConnection.class) {
			if(instance==null){
				instance = new DBConnection();
			}
		}
		return instance;
	}
	
	
	
	public static Connection getConnection() throws TruckException , SQLException{
		if(connection==null){
			getInstance();
			return dataSource.getConnection();
		}
		return connection;
	}

}
