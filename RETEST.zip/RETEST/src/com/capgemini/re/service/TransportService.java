package com.capgemini.re.service;

import java.util.List;

import com.capgemini.re.bean.TruckBean;
import com.capgemini.re.dao.ITransportDao;
import com.capgemini.re.dao.TransportDao;
import com.capgemini.re.exception.TruckException;

public class TransportService implements ITransportService{
	private ITransportDao transportDAO= new TransportDao();

	@Override
	public List<TruckBean> getAllTruckDetails() throws TruckException {
List<TruckBean>truckList =	 transportDAO.getAllTruckDetails();
		return truckList;
	}

	@Override
	public boolean isValidtruckId(Long truckId) throws TruckException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Integer updateavailableNos(Integer truckId, Integer availableNos)
			throws TruckException {
		// TODO Auto-generated method stub
		return null;
	}

}
