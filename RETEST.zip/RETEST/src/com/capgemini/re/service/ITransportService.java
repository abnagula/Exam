package com.capgemini.re.service;

import java.util.List;

import com.capgemini.re.bean.TruckBean;
import com.capgemini.re.exception.TruckException;

public interface ITransportService {
	public List<TruckBean > getAllTruckDetails() throws TruckException;
	public boolean isValidtruckId(Long truckId) throws TruckException;

	public Integer updateavailableNos(Integer truckId, Integer availableNos) throws TruckException;

}
