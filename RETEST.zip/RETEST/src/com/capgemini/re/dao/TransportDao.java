package com.capgemini.re.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;





import com.capgemini.re.bean.TruckBean;
import com.capgemini.re.exception.TruckException;
import com.capgemini.re.util.DBConnection;



public class TransportDao implements ITransportDao {
	

	@Override
	public List< TruckBean> getAllTruckDetails() throws TruckException {
	String sql= "select * from TruckDetails";
	int truckCount=0;

	try(
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			){
		ResultSet resultSet= preparedStatement.executeQuery();
		List<TruckBean>truckList= new ArrayList<>();
		while(resultSet.next()){
			truckCount++;
			TruckBean truck = new TruckBean();
			populateTruckBean(truck,resultSet);
			truckList.add(truck);
		}
			if(truckCount>0){
				return truckList;
			}else {
				return null;
			}
			
	
	}catch(SQLException e)
	{	
	e.printStackTrace();
	throw new TruckException("technical error");
	}


}

	private void populateTruckBean(TruckBean truck, ResultSet resultSet) throws SQLException {
	truck.setTruckId(resultSet.getInt("truckid"));
	truck.setTruckType(resultSet.getString("truckType"));
	truck.setOrigin(resultSet.getString("origin"));
	truck.setDestination(resultSet.getString("destination"));
	truck.setCharges(resultSet.getInt("charges"));
	truck.setAvailableNos(resultSet.getInt("availableNos"));
		
	}

	

	@Override
	public boolean isValidtruckId(Long truckId) throws TruckException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Integer updateavailableNos(Integer truckId, Integer availableNos)
			throws TruckException {
     String sql= " update BookingDetails set availableNos=availableNos-? where truckid=?";
     try(
    			Connection connection=DBConnection.getConnection();
 			PreparedStatement preparedStatement=connection.prepareStatement(sql);
    		 ){
    	 
     }catch(){
    	 
     }
		return null;
	}

}
