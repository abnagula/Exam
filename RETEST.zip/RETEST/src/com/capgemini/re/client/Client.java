package com.capgemini.re.client;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;


import com.capgemini.re.bean.TruckBean;
import com.capgemini.re.exception.TruckException;
import com.capgemini.re.service.ITransportService;
import com.capgemini.re.service.TransportService;

public class Client {
	private static ITransportService transportSer= new TransportService();
private static Scanner sc= new Scanner(System.in);
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("  TRANSPORT SYSTEM ");
			System.out.println("_______________________________\n");

			System.out.println("1:BOOK VEHICLE ");
		//	System.out.println("2.Search Mobile based on Price Range");
			//System.out.println("3.Retrive All Mobiles");
			//System.out.println("4.Delete Mobile");
			//System.out.println("5.Purchase  Mobile");
			//System.out.println("6.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept o
		
		
		
		try{
			
			int	option = sc.nextInt();
		switch(option){
		case 1:
			System.out.println("Enter customer id: ");
			Integer cid = sc.nextInt();
			List<TruckBean> truckList=getAllTruckDetails();
            showTrucks(truckList);
			
		}
		
		}catch(InputMismatchException e){
			System.out.println("technical error at client");
			
		}
	

	}

}
	private static void showTrucks(List<TruckBean> truckList) {
		Iterator<TruckBean> iterator= truckList.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
		
	}
	private static List<TruckBean> getAllTruckDetails() {
		List<TruckBean>truckList;
		try{
		truckList=transportSer.getAllTruckDetails();
		return truckList;
		
		}catch(TruckException e){
			System.out.println(e.getMessage());
			
			
		}
		return null;
	}
}